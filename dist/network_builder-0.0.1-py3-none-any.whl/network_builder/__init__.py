"""
This is the __init__.py file for the Network_Builder package.
It imports the main function from the network_builder module.
"""
from .network_builder import main